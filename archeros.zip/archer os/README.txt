to install, open install.bat
to uninstall, run Uninstall.bat
The key is 8946, when you are done editing your version of ArcherOS, you can change the product key.
this is made in Batch.
this is made by an 11 year old, so please be kind :)
EXTRACT THE FOLDER
ArcherOS Beta W.I.P 